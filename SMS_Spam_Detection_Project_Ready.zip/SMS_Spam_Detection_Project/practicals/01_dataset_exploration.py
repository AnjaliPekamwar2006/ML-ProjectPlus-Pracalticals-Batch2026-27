import pandas as pd
df = pd.read_csv("data/SMSSpamCollection", sep="\t", header=None, names=["label", "message"], encoding="latin-1")
print(df.head())
print("\nDataset shape:", df.shape)
print("\nMissing values:\n", df.isnull().sum())
print("\nClass counts:\n", df["label"].value_counts())
