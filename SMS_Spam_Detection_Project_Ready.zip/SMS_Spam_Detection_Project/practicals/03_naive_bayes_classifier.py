import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
df = pd.read_csv("data/SMSSpamCollection", sep="\t", header=None, names=["label", "message"], encoding="latin-1")
X_train, X_test, y_train, y_test = train_test_split(df.message, df.label, test_size=0.2, random_state=42, stratify=df.label)
model = make_pipeline(TfidfVectorizer(stop_words="english"), MultinomialNB())
model.fit(X_train, y_train)
print("Test predictions:", model.predict(X_test[:5].tolist()))
print("Actual labels:", y_test.iloc[:5].tolist())
