# Project-linked ML practical exercises

These are supplementary exercises for learning and demonstration. Your teacher's official lab-manual practicals must also be completed and uploaded separately.

1. `01_dataset_exploration.py` – load data and inspect labels.
2. `02_text_vectorization.py` – convert messages into TF-IDF features.
3. `03_naive_bayes_classifier.py` – train a Naive Bayes classifier.
4. `04_model_evaluation.py` – calculate classification metrics and confusion matrix.

Run each script from the project root after downloading the full dataset:
`python data/download_dataset.py`
