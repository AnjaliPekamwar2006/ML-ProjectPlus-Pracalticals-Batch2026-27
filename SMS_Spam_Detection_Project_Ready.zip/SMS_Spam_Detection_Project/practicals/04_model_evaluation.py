import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
df = pd.read_csv("data/SMSSpamCollection", sep="\t", header=None, names=["label", "message"], encoding="latin-1")
X_train, X_test, y_train, y_test = train_test_split(df.message, df.label, test_size=0.2, random_state=42, stratify=df.label)
model = make_pipeline(TfidfVectorizer(stop_words="english"), MultinomialNB()).fit(X_train, y_train)
pred = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, pred))
print(classification_report(y_test, pred, zero_division=0))
print("Confusion matrix:\n", confusion_matrix(y_test, pred, labels=["ham", "spam"]))
