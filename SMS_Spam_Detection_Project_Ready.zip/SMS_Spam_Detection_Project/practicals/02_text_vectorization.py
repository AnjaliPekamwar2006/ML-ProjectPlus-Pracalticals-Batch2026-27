import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
df = pd.read_csv("data/SMSSpamCollection", sep="\t", header=None, names=["label", "message"], encoding="latin-1")
vectorizer = TfidfVectorizer(stop_words="english", max_features=1000)
X = vectorizer.fit_transform(df["message"])
print("Original messages:", len(df))
print("TF-IDF matrix shape:", X.shape)
print("Sample vocabulary:", list(vectorizer.get_feature_names_out()[:20]))
