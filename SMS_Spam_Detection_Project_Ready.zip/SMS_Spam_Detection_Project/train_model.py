from pathlib import Path
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data" / "SMSSpamCollection"
MODEL_DIR = ROOT / "models"
MODEL_DIR.mkdir(exist_ok=True)

def load_data():
    if not DATA.exists():
        raise FileNotFoundError("Full dataset not found. Run: python data/download_dataset.py")
    df = pd.read_csv(DATA, sep="\t", header=None, names=["label", "message"], encoding="latin-1")
    df = df.dropna().drop_duplicates()
    df = df[df["label"].isin(["ham", "spam"])]
    return df

def main():
    df = load_data()
    X_train, X_test, y_train, y_test = train_test_split(
        df["message"], df["label"], test_size=0.20, random_state=42, stratify=df["label"]
    )
    model = Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english", ngram_range=(1, 2), max_features=5000)),
        ("classifier", MultinomialNB())
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    print(f"Total records: {len(df)}")
    print(f"Accuracy: {accuracy_score(y_test, predictions):.4f}")
    print("\nClassification report:\n", classification_report(y_test, predictions, zero_division=0))
    cm = confusion_matrix(y_test, predictions, labels=["ham", "spam"])
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Ham", "Spam"], yticklabels=["Ham", "Spam"])
    plt.xlabel("Predicted label"); plt.ylabel("Actual label")
    plt.title("SMS Spam Detection - Confusion Matrix")
    plt.tight_layout()
    plt.savefig(ROOT / "reports" / "confusion_matrix.png", dpi=160)
    joblib.dump(model, MODEL_DIR / "sms_spam_model.joblib")
    print(f"Model saved to {MODEL_DIR / 'sms_spam_model.joblib'}")

if __name__ == "__main__":
    main()
