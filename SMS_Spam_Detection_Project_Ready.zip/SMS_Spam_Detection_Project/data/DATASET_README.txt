FULL DATASET REQUIRED BEFORE TRAINING

The official UCI SMS Spam Collection contains 5,574 labelled SMS messages.
Run from the project root: python data/download_dataset.py
This downloads data/SMSSpamCollection from the official UCI dataset archive.

Citation: Almeida, T. & Hidalgo, J. (2011). SMS Spam Collection. UCI Machine Learning Repository.
https://doi.org/10.24432/C5CC84
License: CC BY 4.0 (as listed by UCI). Keep this attribution when redistributing.

sample_sms.csv is only an 8-row illustrative sample, not the full research dataset.
