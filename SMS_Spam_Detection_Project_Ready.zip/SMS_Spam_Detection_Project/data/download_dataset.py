from pathlib import Path
import urllib.request, zipfile, io

URL = "https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip"
OUT = Path(__file__).resolve().parent / "SMSSpamCollection"

def main():
    if OUT.exists():
        print(f"Dataset already exists: {OUT}")
        return
    print("Downloading UCI SMS Spam Collection...")
    with urllib.request.urlopen(URL, timeout=60) as response:
        archive_bytes = response.read()
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
        OUT.write_bytes(archive.read("SMSSpamCollection"))
    print(f"Saved {OUT}")

if __name__ == "__main__":
    main()
