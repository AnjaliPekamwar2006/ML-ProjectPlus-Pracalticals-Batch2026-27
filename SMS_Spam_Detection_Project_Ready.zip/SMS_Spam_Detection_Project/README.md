# SMS Spam Detection using Machine Learning

A beginner-friendly text classification project that predicts whether an SMS message is **Spam** or **Ham (Not Spam)**.

## Project contents
- `app.py` – Streamlit interface for testing messages.
- `train_model.py` – trains and evaluates a TF-IDF + Multinomial Naive Bayes model.
- `data/sample_sms.csv` – small illustrative sample dataset.
- `data/download_dataset.py` – downloads the full UCI SMS Spam Collection.
- `practicals/` – guided practical exercises related to this project.
- `reports/SMS_Spam_Detection_Report.pdf` – project report.
- `requirements.txt` – Python dependencies.

## Dataset
The full project uses the **UCI SMS Spam Collection** (5,574 labelled messages; ham/spam). Download it from the official UCI page:
https://archive.ics.uci.edu/dataset/228/sms+spam+collection

Run the downloader to place the full dataset at `data/SMSSpamCollection`. The included `sample_sms.csv` is only a tiny illustrative sample, not a replacement for the full dataset. Dataset citation: Almeida, T. & Hidalgo, J. (2011), https://doi.org/10.24432/C5CC84. UCI lists the dataset under CC BY 4.0; retain attribution.

## Setup (Windows / VS Code)
1. Extract this ZIP.
2. Open the extracted `SMS_Spam_Detection_Project` folder in VS Code.
3. Open Terminal → New Terminal.
4. Create a virtual environment:
   `python -m venv .venv`
5. Activate it:
   `.\.venv\Scriptsctivate`
6. Install packages:
   `pip install -r requirements.txt`
7. Download the full dataset:
   `python data/download_dataset.py`
8. Train the model:
   `python train_model.py`
9. Launch the web app:
   `streamlit run app.py`

If PowerShell blocks activation, run `.\.venv\Scripts\python.exe -m pip install -r requirements.txt`, then use `.\.venv\Scripts\python.exe train_model.py` and `.\.venv\Scripts\python.exe -m streamlit run app.py`.

## Methodology
1. Load labelled SMS data.
2. Remove duplicate and empty rows.
3. Convert text to numerical features using TF-IDF.
4. Split data into training and testing sets with stratification.
5. Train a Multinomial Naive Bayes classifier.
6. Evaluate using accuracy, precision, recall, F1-score and confusion matrix.
7. Save the trained pipeline and use it to classify new messages.

## Important
The supplied report is a project-report template with methodology and dataset details. Run the training script and replace the result placeholders with your actual terminal metrics before final submission. Do not claim an accuracy value unless it is produced by your run.
