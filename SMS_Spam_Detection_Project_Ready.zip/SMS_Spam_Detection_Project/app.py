from pathlib import Path
import joblib
import streamlit as st

ROOT = Path(__file__).resolve().parent
MODEL_PATH = ROOT / "models" / "sms_spam_model.joblib"

st.set_page_config(page_title="SMS Spam Detector", page_icon="📩", layout="centered")
st.title("📩 SMS Spam Detection")
st.write("Enter a text message to check whether it looks like spam or a normal message.")
if not MODEL_PATH.exists():
    st.warning("Model not found. First download the dataset and run `python train_model.py`.")
    st.stop()
model = joblib.load(MODEL_PATH)
message = st.text_area("Enter SMS message", placeholder="Example: Congratulations! You won a prize. Click here...")
if st.button("Check Message", type="primary"):
    if not message.strip():
        st.error("Please enter a message.")
    else:
        prediction = model.predict([message])[0]
        if prediction == "spam":
            st.error("⚠️ Prediction: SPAM")
            st.write("Be careful. Do not click unknown links or share OTP, passwords or bank details.")
        else:
            st.success("✅ Prediction: HAM (Not Spam)")
st.caption("Educational demonstration only. Predictions can be wrong; always use your judgement.")
